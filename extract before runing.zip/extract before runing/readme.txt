move the file here to the main folde before running the code 
